Required Components to Execute SSIS Package

- 32bit dtexec utility

Execute Steps

1. Update variables in dtsConfig file with appropriate values
3. Package uses integrated security for database connection make sure user running package has sys admin rights

